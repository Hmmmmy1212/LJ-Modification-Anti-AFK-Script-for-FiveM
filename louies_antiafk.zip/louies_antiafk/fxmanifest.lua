fx_version 'cerulean'
game 'gta5'

author 'Louie'
description 'Anti AFK script - Made By https://discord.gg/6GDps7XzTm'
version '1.0.0'

shared_scripts {
    'config.lua'
}

server_scripts {
    'server/utils.lua',
    'server/framework.lua',
    'server/main.lua'
}

-- Optional client script for visual warnings
client_scripts {
    'client/warnings.lua'
}