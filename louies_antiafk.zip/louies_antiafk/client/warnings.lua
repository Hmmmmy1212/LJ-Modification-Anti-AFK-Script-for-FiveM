-- Client-side visual warnings
local showingWarning = false

-- Show final warning on screen
RegisterNetEvent('afk:showFinalWarning')
AddEventHandler('afk:showFinalWarning', function()
    showingWarning = true
    
    Citizen.CreateThread(function()
        local endTime = GetGameTimer() + 30000 -- 30 seconds
        
        while showingWarning and GetGameTimer() < endTime do
            -- Calculate remaining time
            local remaining = math.floor((endTime - GetGameTimer()) / 1000)
            
            -- Draw warning on screen
            SetTextFont(4)
            SetTextScale(1.0, 1.0)
            SetTextColour(255, 0, 0, 255)
            SetTextDropshadow(0, 0, 0, 0, 255)
            SetTextEdge(2, 0, 0, 0, 150)
            SetTextDropShadow()
            SetTextOutline()
            SetTextCentre(true)
            
            BeginTextCommandDisplayText("STRING")
            AddTextComponentSubstringPlayerName("WARNING: You will be kicked for AFK in " .. remaining .. " seconds!")
            EndTextCommandDisplayText(0.5, 0.1)
            
            Citizen.Wait(0)
        end
        
        showingWarning = false
    end)
end)

-- Reset warning when player moves
Citizen.CreateThread(function()
    local lastPos = GetEntityCoords(PlayerPedId())
    
    while true do
        Citizen.Wait(1000)
        
        local currentPos = GetEntityCoords(PlayerPedId())
        local distance = #(currentPos - lastPos)
        
        if distance > 1.0 then
            showingWarning = false
            lastPos = currentPos
        end
    end
end)