Config = {}

-- Framework Detection (Auto-detects framework)
-- Options: 'auto', 'esx', 'qb', 'standalone'
Config.Framework = 'auto'

-- AFK Settings
Config.AFKKickTime = 15            -- Minutes before kick
Config.WarningTime = 13            -- Minutes before warning
Config.CheckInterval = 60          -- Seconds between checks
Config.MovementThreshold = 1.0     -- Distance in meters to consider movement

-- Warning Settings
Config.WarningMessage = "You will be kicked in 2 minutes for being AFK. Move or type something to cancel!"
Config.FinalWarningMessage = "FINAL WARNING: You will be kicked in 30 seconds!"
Config.UseScreenWarning = true     -- Show on-screen warning (requires client script)
Config.UseChatWarning = true       -- Show chat warning

-- Kick Message
Config.KickMessage = "Kicked for being AFK for more than 15 minutes"

-- Exclusions
Config.ExcludedJobs = {
    'admin',
    'moderator',
    'staff'
}

Config.ExcludedPerms = {
    'admin',
    'moderator'
}

Config.ExcludedSteamIDs = {
    -- 'steam:110000112345678' -- Add specific Steam IDs to exclude
}

-- Auto-Reset Actions
Config.AutoResetOn = {
    ['chat'] = true,
    ['commands'] = true,
    ['vehicles'] = true,
    ['inventory'] = true,
    ['weapons'] = true,
    ['phone'] = true,
    ['interactions'] = true,
    ['menu'] = true
}

-- Logging
Config.LogKicks = true
Config.LogToConsole = true
Config.LogToFile = true
Config.LogPath = 'afk-kicks.log'

-- Advanced Settings
Config.UseDatabase = false         -- Store AFK data in database (for persistence)
Config.WhitelistMode = false       -- Only kick non-whitelisted players
Config.AntiCheatCompatible = true  -- Avoid anti-cheat triggers