-- AFK Tracking Tables
local PlayerAFKTime = {}
local PlayerLastPosition = {}
local PlayerLastAction = {}
local PlayerWarnings = {}

-- Reset player AFK timer
local function ResetPlayerAFKTimer(source)
    PlayerAFKTime[source] = nil
    PlayerLastAction[source] = os.time()
    PlayerWarnings[source] = nil
end

-- Check if player is AFK
local function IsPlayerAFK(source)
    local ped = GetPlayerPed(source)
    
    -- Check if ped exists
    if not ped or ped == 0 then
        return true
    end
    
    local currentPos = GetEntityCoords(ped)
    local lastPos = PlayerLastPosition[source]
    
    -- Initialize if first time
    if not lastPos then
        PlayerLastPosition[source] = currentPos
        PlayerLastAction[source] = os.time()
        return false
    end
    
    -- Check movement
    local distance = #(currentPos - lastPos)
    if distance > Config.MovementThreshold then
        PlayerLastPosition[source] = currentPos
        PlayerLastAction[source] = os.time()
        return false
    end
    
    -- Check recent actions
    if PlayerLastAction[source] then
        local timeSinceAction = os.time() - PlayerLastAction[source]
        if timeSinceAction < 60 then
            return false
        end
    end
    
    return true
end

-- Send warning to player
local function SendAFKWarning(source, warningType)
    if warningType == "first" then
        if Config.UseChatWarning then
            Framework.Notify(source, Config.WarningMessage, "warning")
        end
    elseif warningType == "final" then
        if Config.UseChatWarning then
            Framework.Notify(source, Config.FinalWarningMessage, "error")
        end
        
        if Config.UseScreenWarning then
            TriggerClientEvent('afk:showFinalWarning', source)
        end
    end
end

-- Kick player
local function KickPlayer(source)
    local identifier = UniversalAFK.GetIdentifier(source)
    local name = UniversalAFK.GetPlayerName(source)
    local afkTime = PlayerAFKTime[source] and math.floor((os.time() - PlayerAFKTime[source]) / 60) or Config.AFKKickTime
    
    -- Log the kick
    UniversalAFK.LogKick(source, identifier, name, afkTime)
    
    -- Drop player
    DropPlayer(source, Config.KickMessage)
    
    -- Cleanup
    PlayerAFKTime[source] = nil
    PlayerLastPosition[source] = nil
    PlayerLastAction[source] = nil
    PlayerWarnings[source] = nil
end

-- Main AFK check loop
local function CheckAFKPlayers()
    local currentTime = os.time()
    
    for _, playerId in ipairs(GetPlayers()) do
        local source = tonumber(playerId)
        
        -- Skip if excluded
        if UniversalAFK.IsPlayerExcluded(source) then
            goto continue
        end
        
        if IsPlayerAFK(source) then
            -- Initialize AFK time
            if not PlayerAFKTime[source] then
                PlayerAFKTime[source] = currentTime
            end
            
            local afkMinutes = math.floor((currentTime - PlayerAFKTime[source]) / 60)
            
            -- Send warnings
            if afkMinutes >= Config.WarningTime and afkMinutes < Config.WarningTime + 1 then
                if not PlayerWarnings[source] then
                    SendAFKWarning(source, "first")
                    PlayerWarnings[source] = true
                end
            elseif afkMinutes >= Config.AFKKickTime - 0.5 then
                -- Final warning 30 seconds before kick
                SendAFKWarning(source, "final")
            end
            
            -- Kick player
            if afkMinutes >= Config.AFKKickTime then
                KickPlayer(source)
            end
        else
            -- Player is active, reset timer
            ResetPlayerAFKTimer(source)
        end
        
        ::continue::
    end
end

-- ==============================================
-- ACTION DETECTORS (Auto-Reset)
-- ==============================================

-- Detect chat messages
if Config.AutoResetOn['chat'] then
    AddEventHandler('chatMessage', function(source, name, message)
        ResetPlayerAFKTimer(source)
    end)
end

-- Detect commands (universal method)
if Config.AutoResetOn['commands'] then
    local commandReset = function(source)
        ResetPlayerAFKTimer(source)
    end
    
    -- Hook into existing command events
    AddEventHandler('esx:useItem', commandReset)
    AddEventHandler('esx:onUseItem', commandReset)
    AddEventHandler('QBCore:Server:OnPlayerLoaded', commandReset)
    AddEventHandler('QBCore:Server:OnPlayerUnload', commandReset)
    
    -- Override RegisterCommand for universal command detection
    local originalRegisterCommand = RegisterCommand
    RegisterCommand = function(name, handler, restricted)
        local wrappedHandler = function(source, args, raw)
            ResetPlayerAFKTimer(source)
            if handler then
                return handler(source, args, raw)
            end
        end
        return originalRegisterCommand(name, wrappedHandler, restricted)
    end
end

-- Detect vehicle actions
if Config.AutoResetOn['vehicles'] then
    AddEventHandler('baseevents:enteringVehicle', commandReset)
    AddEventHandler('baseevents:enteredVehicle', commandReset)
    AddEventHandler('baseevents:exitedVehicle', commandReset)
    AddEventHandler('baseevents:leftVehicle', commandReset)
end

-- Detect inventory actions
if Config.AutoResetOn['inventory'] then
    AddEventHandler('inventory:server:OpenInventory', commandReset)
    AddEventHandler('inventory:server:UseItemSlot', commandReset)
    AddEventHandler('esx_inventory:itemUsed', commandReset)
    AddEventHandler('esx_inventory:openInventory', commandReset)
end

-- Detect weapon actions
if Config.AutoResetOn['weapons'] then
    AddEventHandler('weapon:used', commandReset)
    AddEventHandler('weapons:client:SetCurrentWeapon', commandReset)
end

-- Detect phone usage
if Config.AutoResetOn['phone'] then
    AddEventHandler('qb-phone:server:sendMessage', commandReset)
    AddEventHandler('qb-phone:server:addContact', commandReset)
    AddEventHandler('qb-phone:server:bankTransfer', commandReset)
    AddEventHandler('esx_phone:send', commandReset)
end

-- ==============================================
-- EVENT HANDLERS
-- ==============================================

-- Player joining
AddEventHandler('playerJoining', function()
    local source = source
    PlayerLastPosition[source] = nil
    PlayerAFKTime[source] = nil
    PlayerLastAction[source] = nil
    PlayerWarnings[source] = nil
end)

-- Player leaving
AddEventHandler('playerDropped', function(reason)
    local source = source
    PlayerLastPosition[source] = nil
    PlayerAFKTime[source] = nil
    PlayerLastAction[source] = nil
    PlayerWarnings[source] = nil
end)

-- ==============================================
-- COMMANDS
-- ==============================================

-- Manual reset command
RegisterCommand('resetafk', function(source)
    ResetPlayerAFKTimer(source)
    Framework.Notify(source, "Your AFK timer has been reset!", "success")
end, false)

-- AFK status check
RegisterCommand('afkstatus', function(source)
    local afkMinutes = 0
    if PlayerAFKTime[source] then
        afkMinutes = math.floor((os.time() - PlayerAFKTime[source]) / 60)
    end
    
    local statusMsg = string.format("AFK Status: %d/%d minutes", afkMinutes, Config.AFKKickTime)
    if afkMinutes >= Config.WarningTime then
        statusMsg = statusMsg .. " (WARNING: Kick soon!)"
    end
    
    Framework.Notify(source, statusMsg, "primary")
end, false)

-- Admin command to check all players
RegisterCommand('afkcheck', function(source)
    if not Framework.HasPermission(source, 'admin') then
        Framework.Notify(source, "No permission!", "error")
        return
    end
    
    for _, playerId in ipairs(GetPlayers()) do
        local plySource = tonumber(playerId)
        local name = GetPlayerName(plySource)
        local afkMinutes = 0
        
        if PlayerAFKTime[plySource] then
            afkMinutes = math.floor((os.time() - PlayerAFKTime[plySource]) / 60)
        end
        
        local status = afkMinutes > 0 and string.format("AFK for %d minutes", afkMinutes) or "Active"
        TriggerClientEvent('chat:addMessage', source, {
            color = {0, 255, 255},
            args = {'AFK Check', string.format("%s (ID: %d): %s", name, plySource, status)}
        })
    end
end, true)

-- ==============================================
-- INITIALIZATION
-- ==============================================

-- Start AFK check loop
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(Config.CheckInterval * 1000)
        CheckAFKPlayers()
    end
end)

-- Initialization complete
Citizen.CreateThread(function()
    Wait(5000) -- Wait for resources to load
    UniversalAFK.Log("Universal Anti-AFK System Initialized", "success")
    UniversalAFK.Log(string.format("Framework: %s | Kick Time: %d minutes", Framework.type, Config.AFKKickTime), "info")
end)