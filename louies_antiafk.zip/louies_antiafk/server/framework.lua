-- Framework handler
Framework = {}

Framework.type = UniversalAFK.DetectFramework()
UniversalAFK.Log("Detected framework: " .. Framework.type, "info")

-- Get player object based on framework
Framework.GetPlayer = function(source)
    if Framework.type == 'esx' then
        local ESX = exports['es_extended']:getSharedObject()
        return ESX.GetPlayerFromId(source)
    elseif Framework.type == 'qb' then
        local QBCore = exports['qb-core']:GetCoreObject()
        return QBCore.Functions.GetPlayer(source)
    else
        return nil -- Standalone
    end
end

-- Send notification based on framework
Framework.Notify = function(source, message, type)
    if Framework.type == 'esx' then
        TriggerClientEvent('esx:showNotification', source, message)
    elseif Framework.type == 'qb' then
        TriggerClientEvent('QBCore:Notify', source, message, type or 'primary')
    else
        -- Standalone - use chat message
        TriggerClientEvent('chat:addMessage', source, {
            color = {255, 255, 0},
            args = {'SYSTEM', message}
        })
    end
end

-- Get player job/group
Framework.GetPlayerGroup = function(source)
    local player = Framework.GetPlayer(source)
    
    if Framework.type == 'esx' and player then
        return player.job.name
    elseif Framework.type == 'qb' and player then
        return player.PlayerData.job.name
    end
    
    return 'citizen'
end

-- Check if player has permission
Framework.HasPermission = function(source, permission)
    if Framework.type == 'esx' then
        local player = Framework.GetPlayer(source)
        if player then
            -- ESX group system
            for groupName, _ in pairs(player.getGroups()) do
                if groupName == permission then
                    return true
                end
            end
        end
    elseif Framework.type == 'qb' then
        local QBCore = exports['qb-core']:GetCoreObject()
        return QBCore.Functions.HasPermission(source, permission)
    end
    
    -- Standalone - use ACE permissions
    return IsPlayerAceAllowed(source, permission)
end