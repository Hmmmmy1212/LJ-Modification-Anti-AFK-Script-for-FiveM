UniversalAFK = {}

-- Framework detection
UniversalAFK.DetectFramework = function()
    if Config.Framework ~= 'auto' then
        return Config.Framework
    end
    
    -- Auto-detect framework
    if GetResourceState('es_extended') == 'started' then
        return 'esx'
    elseif GetResourceState('qb-core') == 'started' then
        return 'qb'
    else
        return 'standalone'
    end
end

-- Get player name
UniversalAFK.GetPlayerName = function(source)
    local name = GetPlayerName(source)
    return name or "Unknown"
end

-- Get player identifier
UniversalAFK.GetIdentifier = function(source)
    local identifiers = GetPlayerIdentifiers(source)
    for _, identifier in ipairs(identifiers) do
        if string.sub(identifier, 1, string.len("steam:")) == "steam:" then
            return identifier
        elseif string.sub(identifier, 1, string.len("license:")) == "license:" then
            return identifier
        end
    end
    return "unknown"
end

-- Check if player is excluded
UniversalAFK.IsPlayerExcluded = function(source)
    local framework = UniversalAFK.DetectFramework()
    local identifier = UniversalAFK.GetIdentifier(source)
    
    -- Check Steam ID exclusions
    for _, excludedID in ipairs(Config.ExcludedSteamIDs) do
        if identifier == excludedID then
            return true
        end
    end
    
    -- Framework-specific exclusions
    if framework == 'esx' then
        local ESX = exports['es_extended']:getSharedObject()
        local xPlayer = ESX.GetPlayerFromId(source)
        if xPlayer then
            local playerJob = xPlayer.job.name
            for _, job in ipairs(Config.ExcludedJobs) do
                if playerJob == job then
                    return true
                end
            end
        end
    elseif framework == 'qb' then
        local QBCore = exports['qb-core']:GetCoreObject()
        local Player = QBCore.Functions.GetPlayer(source)
        if Player then
            local playerJob = Player.PlayerData.job.name
            for _, job in ipairs(Config.ExcludedJobs) do
                if playerJob == job then
                    return true
                end
            end
        end
    end
    
    -- Check permissions (for standalone/any framework)
    if IsPlayerAceAllowed(source, "admin") then
        return true
    end
    
    return false
end

-- Logging functions
UniversalAFK.Log = function(message, level)
    local prefix = "[Anti-AFK] "
    local timestamp = os.date("%Y-%m-%d %H:%M:%S")
    
    if Config.LogToConsole then
        local color = "^7"
        if level == "error" then color = "^1"
        elseif level == "success" then color = "^2"
        elseif level == "warning" then color = "^3"
        elseif level == "info" then color = "^5"
        end
        print(color .. prefix .. message .. "^7")
    end
    
    if Config.LogToFile then
        local logMessage = string.format("[%s] %s%s\n", timestamp, prefix, message)
        local file = io.open(Config.LogPath, "a")
        if file then
            file:write(logMessage)
            file:close()
        end
    end
end

UniversalAFK.LogKick = function(source, identifier, name, afkTime)
    local framework = UniversalAFK.DetectFramework()
    local logMessage = string.format(
        "Player %s (ID: %s - %s - Framework: %s) kicked for AFK (%d minutes)",
        name, identifier, source, framework, afkTime
    )
    UniversalAFK.Log(logMessage, "warning")
end